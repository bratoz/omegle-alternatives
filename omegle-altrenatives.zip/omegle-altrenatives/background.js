
const UNINSTALL_URL = "https://extension.n1.chat/delete.html";
chrome.runtime.setUninstallURL(UNINSTALL_URL);
chrome.action.onClicked.addListener(function(tab) {
    chrome.tabs.create({'url': chrome.runtime.getURL('newtab.html')}, function(tab) {
        // Tab opened.
    });
});

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === chrome.runtime.OnInstalledReason.INSTALL) {
        // Код, который будет выполнен при первой установке
        // например, открыть вкладку с URL
        chrome.tabs.create({
            url: "https://extension.n1.chat/welcome.html",
        });
    } else if (details.reason === chrome.runtime.OnInstalledReason.UPDATE) {
        // Когда расширение обновлено
    } else if (
        details.reason === chrome.runtime.OnInstalledReason.CHROME_UPDATE
    ) {
        // Когда браузер обновлён
    } else if (
        details.reason === chrome.runtime.OnInstalledReason.SHARED_MODULE_UPDATE
    ) {
        // Когда обновлен общий модуль
    }
});
